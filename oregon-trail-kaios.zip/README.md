# Oregon Trail:KaiOS Edition

Prototype KaiOS-friendly recreation of an Oregon Trail style game.

**Developer:** ChingaApps

## What this is

A small, open prototype intended to run on KaiOS devices or in a desktop browser for testing. It is a simple travel loop with supplies and random events.

## Run locally (quick test)

1. Start a simple HTTP server from the project root:

```bash
cd /workspaces/Oregon-Trail-KaiOS-Edition
python3 -m http.server 8000
```

2. Open `http://localhost:8000` in a browser on your development machine or device.

Use keys `1`, `2`, `3` to choose options.

## Package for KaiOS

1. Ensure `manifest.webapp` and the site root files are present.
2. Create a zip with the site files (icons should be in `icons/`):

```bash
zip -r oregon-trail-kaios.zip index.html css js manifest.webapp icons README.md
```

3. Upload or sideload the zip to a KaiOS device or emulator according to the platform documentation.

## Notes & next steps

- This is a prototype. Next improvements: deeper event trees, art and audio, save state, multiple routes.
- No em-dash characters were used in code files.
