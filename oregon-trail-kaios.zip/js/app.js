/* Lightweight Oregon Trail style prototype for KaiOS
   Title: Oregon Trail:KaiOS Edition
   Developer: ChingaApps

   Notes: Keep code simple and keypad-friendly. Avoid em-dashes in code.
*/

const app = document.getElementById('app');
const main = document.getElementById('main');
const leftSoft = document.getElementById('left-soft');
const rightSoft = document.getElementById('right-soft');

const GAME = {
  state: 'start',
  day: 0,
  milesLeft: 2040,
  food: 200,
  party: 4,
  health: 100,
  wounded: 0
};

function rand(min, max){return Math.floor(Math.random()*(max-min+1))+min}

function setSoftkeys(left, right){
  leftSoft.textContent = left || '';
  rightSoft.textContent = right || '';
}

function render(){
  main.innerHTML = '';
  if(GAME.state === 'start'){
    const title = el('div', {class:'card'}, html(`Welcome to Oregon Trail:KaiOS Edition`));
    const desc = el('div',{class:'card'}, html(`You are leading a party of ${GAME.party} on a journey to Oregon.`));
    const choices = el('div',{class:'choices'}, '');
    choices.appendChild(choice(1, 'Start journey'));
    choices.appendChild(choice(2, 'Instructions'));
    choices.appendChild(choice(3, 'Reset progress')));
    main.appendChild(title);
    main.appendChild(desc);
    main.appendChild(statusCard());
    main.appendChild(choices);
    setSoftkeys('1:Select','3:Back');
    return;
  }

  if(GAME.state === 'travel'){
    main.appendChild(el('div',{class:'card'}, html(`Day ${GAME.day}`)));
    main.appendChild(statusCard());
    main.appendChild(el('div',{class:'card'}, html(`Miles to go: ${GAME.milesLeft}`)));

    const choices = el('div',{class:'choices'}, '');
    choices.appendChild(choice(1,'Travel'));
    choices.appendChild(choice(2,'Hunt for food'));
    choices.appendChild(choice(3,'Rest'));
    main.appendChild(choices);
    setSoftkeys('1:Select','3:Back');
    return;
  }

  if(GAME.state === 'event'){
    main.appendChild(el('div',{class:'card'}, html(GAME.message || 'An event occurred.')));
    main.appendChild(statusCard());
    const choices = el('div',{class:'choices'}, '');
    choices.appendChild(choice(1,'Continue'));
    main.appendChild(choices);
    setSoftkeys('1:Select','3:Back');
    return;
  }

  if(GAME.state === 'gameover'){
    main.appendChild(el('div',{class:'card'}, html(`<span class="danger">Game Over</span>`)));
    main.appendChild(el('div',{class:'card'}, html(`You lasted ${GAME.day} days.`)));
    main.appendChild(el('div',{class:'choices'}, ''));
    setSoftkeys('','3:Back');
    return;
  }

  if(GAME.state === 'win'){
    main.appendChild(el('div',{class:'card'}, html(`<strong>You reached Oregon!</strong>`)));
    main.appendChild(el('div',{class:'card'}, html(`Days: ${GAME.day} Food left: ${GAME.food}`)));
    setSoftkeys('','3:Back');
    return;
  }
}

function statusCard(){
  return el('div',{class:'card status'}, html(`Food: ${GAME.food} | Party: ${GAME.party} | Health: ${GAME.health}`));
}

function el(tag, attrs, content){
  const d = document.createElement(tag);
  if(attrs){
    Object.keys(attrs).forEach(k=>d.setAttribute(k, attrs[k]));
  }
  if(typeof content === 'string') d.innerHTML = content;
  else if(content instanceof Node) d.appendChild(content);
  return d;
}

function html(str){return str}

function choice(n, text){
  const c = el('button',{class:'choice','data-choice':n}, html(`<b>${n}</b> ${text}`));
  c.addEventListener('click', ()=>onChoice(n));
  return c;
}

function onChoice(n){
  if(GAME.state === 'start'){
    if(n===1){ GAME.state='travel'; GAME.day=1; render(); }
    if(n===2){ GAME.state='event'; GAME.message='Use 1,2,3 keys to pick options. Travel consumes food and moves you toward Oregon.'; render(); }
    if(n===3){ resetGame(); render(); }
    return;
  }

  if(GAME.state === 'travel'){
    if(n===1) doTravel();
    if(n===2) doHunt();
    if(n===3) doRest();
    return;
  }

  if(GAME.state === 'event'){
    GAME.state = 'travel'; render(); return;
  }

  if(GAME.state === 'gameover' || GAME.state === 'win'){
    resetGame(); render(); return;
  }
}

function doTravel(){
  const miles = rand(20,60);
  GAME.milesLeft = Math.max(0, GAME.milesLeft - miles);
  const foodUsed = rand(8,18);
  GAME.food = Math.max(0, GAME.food - foodUsed);
  GAME.day += rand(3,7);
  // random event
  if(Math.random() < 0.3) triggerRandomEvent();
  else checkProgress();
}

function doHunt(){
  const gain = rand(10,60);
  const risk = Math.random();
  GAME.food += gain;
  GAME.day += rand(1,3);
  if(risk < 0.15){
    GAME.health -= rand(10,30);
    GAME.message = `Hunt went wrong. You gained ${gain} food but someone was injured.`;
    GAME.state = 'event'; render(); return;
  }
  GAME.message = `You hunted and gained ${gain} food.`;
  GAME.state = 'event'; render();
}

function doRest(){
  GAME.day += rand(1,2);
  GAME.health = Math.min(100, GAME.health + rand(5,15));
  GAME.message = 'You rested and recovered some health.';
  GAME.state = 'event'; render();
}

function triggerRandomEvent(){
  const r = Math.random();
  if(r<0.4){
    const lost = rand(10,50); GAME.food = Math.max(0, GAME.food - lost);
    GAME.message = `Supplies spoiled. Lost ${lost} food.`;
  } else if(r<0.7){
    const inj = rand(5,30); GAME.health = Math.max(0, GAME.health - inj);
    GAME.message = `One of your party fell ill. Health down ${inj}.`;
  } else {
    const help = rand(10,40); GAME.food += help;
    GAME.message = `You met friendly travelers and got ${help} food.`;
  }
  GAME.state = 'event'; render();
}

function checkProgress(){
  if(GAME.food <= 0){ GAME.state='gameover'; render(); return; }
  if(GAME.health <= 0){ GAME.state='gameover'; render(); return; }
  if(GAME.milesLeft <= 0){ GAME.state='win'; render(); return; }
  // continue traveling
  render();
}

function resetGame(){
  GAME.state='start'; GAME.day=0; GAME.milesLeft=2040; GAME.food=200; GAME.party=4; GAME.health=100; GAME.message='';
}

// keypad handling
window.addEventListener('keydown', (e)=>{
  const k = e.key;
  if(k === '1' || k === '2' || k === '3'){
    onChoice(parseInt(k,10));
    e.preventDefault();
  }
  if(k === 'SoftLeft' || k === '1'){
    // left soft behavior - select first choice if present
  }
});

// initial render
resetGame();
render();
